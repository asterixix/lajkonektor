Lajkonektor — raport analityczny

Otwórz raport.html w przeglądarce. Przycisk „Drukuj / zapisz jako PDF” otwiera wydruk; wybierz zapis jako PDF. Raport, tabele i wykresy działają offline i nie wymagają konta.

raport.json można ponownie otworzyć w lokalnym czytniku raportów strony Lajkonektora. Import nie wysyła pliku na serwer.

CSV: UTF-8 z BOM, separator średnik, przecinek dziesiętny. Teksty przypominające formuły mają ochronny apostrof. Pełne oryginalne wartości są w JSON.

Plan: d06aedda87abec97b19c68a8d169a104b5103e1b4d1951cecbe2545f02b2efd2
Zatwierdzenie: Zlecenie użytkownika: Implement the proposed plan. Próba techniczna raportu; interpretacja wyników nie została zatwierdzona przez badacza.
Zapis zatwierdzenia to deklaracja z rozmowy, a nie uwierzytelniony dowód zgody.

Źródła, daty, metody, kompletność i ograniczenia zawiera raport.html i raport.json. Czas pobrania nie jest datą stanu danych.
